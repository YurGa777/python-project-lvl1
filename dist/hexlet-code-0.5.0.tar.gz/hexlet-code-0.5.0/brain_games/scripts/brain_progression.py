#!/usr/bin/env python

from brain_games.games.find_progression import find_progression


def main():
    find_progression()


if __name__ == '__main__':
    main()
