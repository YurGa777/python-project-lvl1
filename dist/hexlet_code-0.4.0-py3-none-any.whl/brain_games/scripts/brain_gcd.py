#!/usr/bin/env python

from brain_games.games.find_gcd import find_gcd


def main():
    find_gcd()


if __name__ == '__main__':
    main()
