#!/usr/bin/env python3

from brain_games.find_even import find_even


def main():
    find_even()


if __name__ == '__main__':
    main()
