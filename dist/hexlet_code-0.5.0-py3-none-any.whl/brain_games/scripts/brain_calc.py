#!/usr/bin/env python

from brain_games.games.find_result import find_result


def main():
    find_result()


if __name__ == '__main__':
    main()
