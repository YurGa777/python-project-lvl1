#!/usr/bin/env python

from brain_games.games.find_prime import find_prime


def main():
    find_prime()


if __name__ == '__main__':
    main()
